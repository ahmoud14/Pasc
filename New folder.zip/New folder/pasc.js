function pascTriangle(){
document.getElementById("toggler").style.visibility="hidden";
document.getElementById("rn").style.visibility="hidden";
            document.getElementById("pasc").innerHTML = "";
            var rows = document.getElementById("rn").value;
            var arr = generate(rows);
            for(var i=0;i<arr.length;i++){
                var div = document.createElement('div');
                div.className ="test"
                for(var j=0;j<arr[i].length;j++){
                    var x = document.createElement('x');
                    x.innerHTML=arr[i][j];
                    x.className ="class";
                    div.appendChild(x);
                }
                document.getElementById("pasc").appendChild(div);
            }
        }
        function generate(n){
            var arr = [];
            var tmp;
            for(var i=0;i<n;i++){
                arr[i]=[];
                for(var j=0; j<=i; j++){
                    if(j==i){
                        arr[i].push(1);
                    }else{
                        tmp = (!!arr[i-1][j-1]?arr[i-1][j-1]:0)+(!!arr[i-1][j]?arr[i-1][j]:0);
                        arr[i].push(tmp);
                    }
                }
            }
            return arr;
        }